import React from 'react';
import ReactDOM from 'react-dom';
import Api from './Api';


ReactDOM.render(
    <Api />,
    document.getElementById('root')
);